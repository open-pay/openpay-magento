<?php

class Openpay_Stores_Block_Checkout_Success extends Mage_Core_Block_Template
{

}