<?php

class Openpay_Banks_Block_Checkout_Success extends Mage_Core_Block_Template
{

}