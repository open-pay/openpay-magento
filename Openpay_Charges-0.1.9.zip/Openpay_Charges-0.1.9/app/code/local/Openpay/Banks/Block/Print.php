<?php

class Openpay_Banks_Block_Print extends Mage_Core_Block_Template
{

}