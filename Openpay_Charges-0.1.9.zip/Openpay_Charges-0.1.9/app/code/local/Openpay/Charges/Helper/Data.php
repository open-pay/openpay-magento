<?php
class Openpay_Charges_Helper_Data extends Mage_Core_Helper_Abstract
{


}